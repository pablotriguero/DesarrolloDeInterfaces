# javafxexample
This is the example of these articles:

- http://www.swtestacademy.com/database-operations-javafx

- https://www.swtestacademy.com/database-operations-javafx/
