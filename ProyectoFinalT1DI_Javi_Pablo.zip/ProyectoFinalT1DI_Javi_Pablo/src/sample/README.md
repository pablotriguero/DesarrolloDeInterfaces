**Articles**:

https://www.swtestacademy.com/getting-started-with-javafx/

https://www.swtestacademy.com/database-operations-javafx/
